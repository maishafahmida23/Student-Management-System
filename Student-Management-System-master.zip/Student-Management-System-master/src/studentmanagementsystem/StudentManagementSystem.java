package studentmanagementsystem;
public class StudentManagementSystem {
    public static void main(String[] args) {
        StudentLogin sl=new StudentLogin();
        sl.setVisible(true);
       
    }
    
}
